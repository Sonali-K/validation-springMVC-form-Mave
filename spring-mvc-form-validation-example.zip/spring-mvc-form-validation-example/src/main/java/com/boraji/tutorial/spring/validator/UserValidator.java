package com.boraji.tutorial.spring.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.boraji.tutorial.spring.model.User;

/**
 * @author imssbora
 */
@Component
public class UserValidator implements Validator {

   @Override
   public boolean supports(Class<?> clazz) {
      return User.class.equals(clazz);
   }

   @Override
   public void validate(Object obj, Errors err) {

      ValidationUtils.rejectIfEmpty(err, "name", "user.name.empty");
      ValidationUtils.rejectIfEmpty(err, "email", "user.email.empty");
      ValidationUtils.rejectIfEmpty(err, "phno", "user.phno.empty");
      ValidationUtils.rejectIfEmpty(err, "gender", "user.gender.empty");
      ValidationUtils.rejectIfEmpty(err, "languages", "user.languages.empty");

      User user = (User) obj;

      Pattern pattern = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
            Pattern.CASE_INSENSITIVE);
      if (!(pattern.matcher(user.getEmail()).matches())) {
         err.rejectValue("email", "user.email.invalid");
      }

      Pattern pattern1 = Pattern.compile("(0/+91)?[7-9][0-9]{9}",
              Pattern.CASE_INSENSITIVE);
        if (!(pattern1.matcher(user.getPhno()).matches())) {
           err.rejectValue("phno", "user.phno.invalid");
           
           
        }
      
    /* Pattern pattern1 = Pattern.compile("(0/91)?[7-9][0-9]{9}");
      Matcher matcher = pattern.matcher(user.getPhno());
      
      if (!(matcher.matches())) {
    	  err.rejectValue("phno", "user.phno.invalid");
      } */
      
 }
     
   }

   
